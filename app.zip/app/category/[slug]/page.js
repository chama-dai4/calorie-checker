import { CATEGORIES, getCategoryBySlug } from "@/lib/chains";
import CategoryContent from "@/components/CategoryContent";

// 静的ビルド対象のスラッグ一覧を生成
export async function generateStaticParams() {
  return CATEGORIES.map((c) => ({ slug: c.slug }));
}

// 動的にメタデータを生成
export async function generateMetadata({ params }) {
  const { slug } = await params;
  const category = getCategoryBySlug(slug);

  if (!category) {
    return { title: "ページが見つかりません | カロリーチェッカー" };
  }

  return {
    title: `${category.name}チェーン店一覧 | カロリーチェッカー`,
    description: `${category.name}のチェーン店メニューのカロリー・栄養素を計算できます。`,
    alternates: {
      canonical: `https://www.calorie-check.com/category/${slug}`,
      languages: {
        "ja": `https://www.calorie-check.com/category/${slug}`,
        "en": `https://www.calorie-check.com/en/category/${slug}`,
        "x-default": `https://www.calorie-check.com/category/${slug}`,
      },
    },
  };
}

export default async function CategoryPage({ params }) {
  const { slug } = await params;
  return <CategoryContent slug={slug} locale="ja" />;
}